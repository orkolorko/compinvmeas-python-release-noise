#!/bin/bash

DIR=$PWD

GLOG=glog-0.3.4
rm -rf glog-*/
tar xzvf "$GLOG".tar.gz
cd "$GLOG" && ./configure --enable-shared=no --enable-static=yes --prefix=$DIR/inst && make && make install
