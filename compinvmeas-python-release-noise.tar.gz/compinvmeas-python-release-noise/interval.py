"""
Functions to work with intervals (only Newton remained for now, there used to be other stuff but it's obsolete)
"""

__all__ = ["interval_newton,NewtonException"]

def interval_newton(f, fprime, I, alpha, epsilon):
    """
    Finds an interval of width epsilon where f(x)-alpha has a zero. f is supposed to be monotonic.
    f and fprime must take and return intervals.
    If alpha is not contained in f(I), returns [I.lower(), I.lower()] or [I.upper(), I.upper()]
    """
    origI = I
    intervalfield = I.parent()
    
    alpha = intervalfield(alpha)
    
    iterations = 0
    while I.absolute_diameter() > epsilon:
        iterations += 1
        if iterations > 100:
            raise ValueError, 'Interval Newton did not converge. Use higher precision?'
        m = intervalfield(I.center())
        intwith = m - (f(m)-alpha)/fprime(I)
        if intwith.lower() >= I.upper():
            return intervalfield(origI.upper())
        if intwith.upper() <= I.lower():
            return intervalfield(origI.lower())
        I = I.intersection(intwith)
    return I

