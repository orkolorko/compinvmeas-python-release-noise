
COMPINVMEAS_OPENCL_PATH = '../CompInvMeas-OpenCL'

# put ['-c'] if compinvmeas-opencl was compiled with -DCPU_ONLY
# leave [] if compiled to used the GPU
COMPINVMEAS_OPENCL_FLAGS = ['-c']
