
from noise_utils import *
from simple_dynamic import *

        
# Create dynamical system
D = SimpleModel(256)

# Step 1: plot the dynamical system
plot_dynamic(D).show()


# Parameters for Step 2.
# in this example, set the noise to 164/2^14 ~= 1/100, and
# we expect the system to contract in about 60 steps
# that is that L^60 is small enough (<< 1)
K = 2**18
Kcoarse = 2**13
num_iter = 60
coarse_noise_abs = 82
Kest = 2**11

# Step 2: compute the invariant measure
meas_vec, meas_L1_error, meas_file, meas_Linf_estimate = \
    compute_measure(D, K, Kcoarse,
                    num_iter, coarse_noise_abs, Kest)


# Step 3: plot the invariant measure
create_plot(meas_file, RR(coarse_noise_abs)/Kcoarse, 10000)


# Step 4: compute the Lyapunov exponent
# compute the observable (log|f'| in this case)
obs_vec, obs_file = compute_log_deriv(D, K)

# we currently assume that there are no singularities...
obs_sing = [] # create_log_deriv_singularities_info(D)

# estimate the observable
meas_Linf_apriori_bound = D.field(Kcoarse) / coarse_noise_abs
lyap_rig, linfo, uinfo = estimate_observable_L1Linf(K, D.field,
                                meas_vec, meas_file,
                                meas_L1_error,
                                meas_Linf_apriori_bound,
                                meas_Linf_estimate,
                                obs_vec, obs_file,
                                obs_sing,
                                lambda x: log(abs(D.f_prime(x))),
                                20, 7)

# print the rigorous lyapunov exponent
print "Lyap rig: [", str(lyap_rig.lower()),",", str(lyap_rig.upper()),"]"

